# Documento de Configuração de um Cluster Kubernetes.

## 1. Sistema Operacional

A presente instalação utiliza o `Debian 10.8 (Buster)`.

## 2. Requisitos Mínimos

- Pelo menos 02 (dois) núcleos de processamento.
- Pelo menos 04 (quatro) GB de memória RAM.
- Pelo menos 20 (vinte) GB de espaço em disco.
- Apenas uma interface de rede com saída para a internet.

## 3. Arquitetura

O presente projeto contará com 03 (três) máquinas, sendo uma *master* e duas *workers*.

- `t-k8s-master-01` será a máquina *master* e responderá, nesta demonstração, pelo IP `192.168.0.221`.
- `t-k8s-worker-01` será uma máquina *worker* e responderá, nesta demonstração, pelo IP `192.168.0.222`.
- `t-k8s-worker-02` será uma máquina *worker* e responderá, nesta demonstração, pelo IP `192.168.0.223`.

Todas as máquinas pertencem ao domínio `al.mt.gov.br`, portanto também podem ser acessadas pelo FQDN `${hostname}.al.mt.gov.br`.

## 4. Configuração

### 4.1. `t-k8s-master-01`

Primeiramente suba seus privilégios para o usuário `root`, para que possamos executar procedimentos de instalação e configuração.

``` bash
su -
```

> Durante a instalação do Sistema Operacional você provavelmente definiu uma senha de acesso para o usuário `root`, por este motivo você não encontrará o comando `sudo`.

#### 4.1.1. Rede

Um dos requisitos é a existência de apenas uma interface de rede em sua máquina virtual, caso contrário você terá que configurar uma série de parâmetros a mais. Para checar execute o comando:

``` bash
ls /sys/class/net | grep -v "lo"
```

O resultado deve retornar apenas uma interface de rede, como por exemplo `enp0s3`.

Caso sua instalação exija duas interfaces de rede fique atento aos seguintes avisos:

- O Kubernetes vai escutar apenas uma interface de rede, então lembra-se de procurar informações relativas a estas configurações.
- A última configuração da diretiva `gateway` no arquivo `/etc/network/interface` será marcada como seu `gateway padrão`, então preencha a diretiva apenas para sua interface com saída para a internet.
- Tome cuidado com as diretivas `auto` e `allow-hotplug` no arquivo `/etc/network/interface`, lembrando que a `auto` apresentará erro em caso de desconexão no seu virtualizador e a `allow-hotplug` só ligará depois de uma entrada bem sucedida.

Você pode obter mais informações em: [Debian network interface setup](https://linuxhint.com/debian_network_interface_setup/), [Configuring static routes in debian or red hat linux systems](https://www.cyberciti.biz/tips/configuring-static-routes-in-debian-or-red-hat-linux-systems.html) e [Two default gateways on one system](https://www.thomas-krenn.com/en/wiki/Two_Default_Gateways_on_One_System).

#### 4.1.2. SSH

Vamos desligar o acesso à `root` via SSH, como medida de segurança, então execute:

``` bash
sed -i "s@#PermitRootLogin prohibit-password@PermitRootLogin no@g" /etc/ssh/sshd_config

systemctl restart sshd
```

#### 4.1.3. Hosts

Se você estiver trabalhando em um `cluster` gerencial e com controle de DNS você pode pular esta etapa, mas no nosso caso preciso informar para o *host* como chegar em seus pares, portanto execute:

``` bash
echo "" >> /etc/hosts
# Descomente a linha abaixo caso seu Sistema Operacional não tenha criado essa entrada durante o processo de instalação. Você pode checar através do comando `ping $(hostname)`.
# echo -e "127.0.0.1\tt-k8s-master-01\tt-k8s-master-01.al.mt.gov.br" >> /etc/hosts
echo -e "192.168.0.222\tt-k8s-worker-01\tt-k8s-worker-01.al.mt.gov.br" >> /etc/hosts
echo -e "192.168.0.223\tt-k8s-worker-02\tt-k8s-worker-02.al.mt.gov.br" >> /etc/hosts
```

#### 4.1.4. Atualização

Neste momento vamos atualizar qualquer pacote que esteja desatualizado.

``` bash
apt update && apt upgrade -y
```

#### 4.1.5. Firewall

Vamos instalar um Firewall para proteger nosso *host*, para o presente caso em tela a subrede `192.168.0.0/24` é considerada como uma rede exclusiva de todo o Cluster, se esta não for sua realidade customize a máscara ou faça a liberação para cada IP diretamente.

``` bash
# O comando para instalar o Firewall
apt install -y ufw

# Vamos aplicar a regra padrão, negar tudo para entrada e liberar tudo para saída.
ufw default deny incoming
ufw default allow outgoing

# Vamos liberar acesso à SSH, para que possamos acessá-lo pelo terminal.
ufw allow ssh

# Vamos liberar as portas recomendadas pelo Kubernetes
ufw allow from 192.168.0.0/24 to any port 6443 proto tcp
ufw allow from 192.168.0.0/24 to any port 2379:2380 proto tcp
ufw allow from 192.168.0.0/24 to any port 10250 proto tcp
ufw allow from 192.168.0.0/24 to any port 10251 proto tcp
ufw allow from 192.168.0.0/24 to any port 10252 proto tcp

# Vamos liberar as portas recomendadas pelo Calico
ufw allow from 192.168.0.0/24 to any port 179 proto tcp
ufw allow from 192.168.0.0/24 to any port 443 proto tcp
ufw allow from 192.168.0.0/24 to any port 6443 proto tcp
ufw allow from 192.168.0.0/24 to any port 5473 proto tcp
ufw allow from 192.168.0.0/24 to any port 2379 proto tcp
ufw allow from 192.168.0.0/24 to any port 4789 proto udp

# Vamos habilitar as regras acima
ufw enable
```

> Os requerimentos podem ser verificados [aqui](https://kubernetes.io/docs/setup/production-environment/tools/kubeadm/install-kubeadm/#check-required-ports) para o Kubernetes e [aqui](https://docs.projectcalico.org/getting-started/kubernetes/requirements) para o Calico.

#### 4.1.6. Docker

Agora vamos instalar o `container runtime` para o [Kubernetes](https://kubernetes.io/docs/setup/production-environment/container-runtimes/), neste caso instalaremos o [Docker](https://docs.docker.com/engine/install/debian/#install-using-the-repository), para isto execute:

``` bash
mkdir -p /etc/docker /etc/systemd/system/docker.service.d

cat <<EOF | tee /etc/docker/daemon.json
{
  "exec-opts": ["native.cgroupdriver=systemd"],
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "100m"
  },
  "storage-driver": "overlay2",
  "bip": "10.199.0.1/16"
}
EOF
```

Vamos instalar as dependências e o próprio `Docker`:

``` bash
apt install -y apt-transport-https ca-certificates curl gnupg-agent software-properties-common

curl -fsSL https://download.docker.com/linux/debian/gpg | apt-key add -
add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/debian $(lsb_release -cs) stable"

apt update && apt install -y docker-ce docker-ce-cli containerd.io --allow-unauthenticated

systemctl enable docker
```

Caso você queira que seu usuário possa controlar contêineres, execute:

``` bash
usermod -aG docker $(logname)
```

#### 4.1.7. Kubernetes

Nós instalaremos uma instância denominada `bare metal` do Kubernetes, e usaremos a ferramenta `kubeadm` para executar esta atividade.

##### 4.1.7.1. Preparação

A [documentação oficial](https://kubernetes.io/docs/setup/production-environment/tools/kubeadm/install-kubeadm/) do `kubeadm` trás uma série de passos prévios antes de instalar o Kubernetes, então execute:

``` bash
cat <<EOF | tee /etc/modules-load.d/k8s.conf
br_netfilter
EOF

cat <<EOF | tee /etc/sysctl.d/k8s.conf
net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1
EOF

sysctl --system
```

> Os filtros acima permitiram que o `iptables` veja o tráfico em modo `bridge`, conforme descrito [aqui](https://kubernetes.io/docs/setup/production-environment/tools/kubeadm/install-kubeadm/#letting-iptables-see-bridged-traffic).

Agora nós precisamos desligar a memória `swap`, para isto execute:

``` bash
sed -i '/ swap / s/^\(.*\)$/#\1/g' /etc/fstab

swapoff -a
```

> Você pode acompanhar este requisito em [You MUST disable swap in order for the kubelet to work properly](https://kubernetes.io/docs/setup/production-environment/tools/kubeadm/install-kubeadm/#before-you-begin).

##### 4.1.7.2. Instalação

Agora nós iremos instalar as dependências e o próprio Kubernetes, que é o conjunto de `kubectl`, `kubeadm` e `kubelet`, além de algumas imagens, para isto siga as instruções:

``` bash
apt install -y apt-transport-https curl

curl -s https://packages.cloud.google.com/apt/doc/apt-key.gpg | apt-key add -

cat <<EOF | tee /etc/apt/sources.list.d/kubernetes.list
deb https://apt.kubernetes.io/ kubernetes-xenial main
EOF

apt update && apt install -y kubelet kubeadm kubectl

apt-mark hold kubelet kubeadm kubectl

kubeadm config images pull --v 5

systemctl enable kubelet
```

##### 4.1.7.3. Rede

Caso você tenha mais de uma interface de rede você terá que informar o `kubelet` qual ele deve escutar, para isto troque o `enp0s8` pela interface de comunicação com os outros nós do cluster, **caso você tenha só uma interface pule este tópico**, caso contrário execute:

``` bash
(PRIVATE_IP=$(ip -f inet addr show enp0s8 | sed -En -e 's/.*inet ([0-9.]+).*/\1/p'); echo "KUBELET_EXTRA_ARGS=--node-ip=$PRIVATE_IP" >> /etc/default/kubelet)

systemctl daemon-reload

systemctl restart kubelet
```

##### 4.1.7.4. Iniciando o Cluster

###### 4.1.7.4.1. Com uma interface de rede

Caso você tenha apenas uma interface de rede, execute:

``` bash
(PRIVATE_IP=$(ip route get $(ip route show 0.0.0.0/0 | grep -oP 'via \K\S+') | grep -oP 'src \K\S+'); kubeadm init --pod-network-cidr=10.198.0.0/16 --service-cidr=10.197.0.0/16 --apiserver-advertise-address=$PRIVATE_IP --control-plane-endpoint=$PRIVATE_IP)
```

###### 4.1.7.4.2. Com mais de uma interface de rede

Caso você tenha mais de uma interface de rede você terá que informar o IP de comunicação dos nós, para isto troque o `enp0s8` pela interface de comunicação com os outros nós do cluster, **caso você tenha só uma interface execute o tópico anterior**, caso contrário execute:

``` bash
(PRIVATE_IP=$(ip -f inet addr show enp0s8 | sed -En -e 's/.*inet ([0-9.]+).*/\1/p'); kubeadm init --pod-network-cidr=10.198.0.0/16 --service-cidr=10.197.0.0/16 --apiserver-advertise-address=$PRIVATE_IP --control-plane-endpoint=$PRIVATE_IP)
```

##### 4.1.7.5. Controlando o Cluster

Você pode controlar o cluster de Kubernetes de qualquer lugar, basicamente tendo acesso ao arquivo `/etc/kubernetes/admin.conf`.

###### 4.1.7.5.1. Como `root`

Você deve executar as instruções para controlar como `root`:

``` bash
export KUBECONFIG=/etc/kubernetes/admin.conf

echo "export KUBECONFIG=/etc/kubernetes/admin.conf" >> ~/.bashrc
```

###### 4.1.7.5.1. Como `non-root`

Você deve executar as instruções para controlar como `non-root`, neste caso ele copiará as configurações para o usuário anterior à sessão de `root`:

``` bash
# Prepare non-root user's variables.
export CURRENT_USER=$(logname)
export CURRENT_HOME=$(getent passwd $CURRENT_USER | cut -d: -f6)

# Connect kubectl's admin file to non-root user.
mkdir -p $CURRENT_HOME/.kube
cp -i /etc/kubernetes/admin.conf $CURRENT_HOME/.kube/config
chown $(id $CURRENT_USER -u):$(id $CURRENT_USER -g) $CURRENT_HOME/.kube/config

# Dispose non-root user's information
unset CURRENT_USER CURRENT_HOME
```

##### 4.1.7.6. Checando a Saúde

Você pode executar o(s) comando(s) abaixo para buscar as informações do seu cluster, se algo deu errado algum dos comandos demonstrará:

``` bash
kubectl cluster-info

systemctl status kubelet

kubectl get nodes -o wide
```

> Caso algo não esteja funcionando adequadamente você pode consultar a [documentação oficial](https://kubernetes.io/docs/tasks/debug-application-cluster/debug-cluster/) de como debuggar o cluster.

##### 4.1.7.7. Calico

Por padrão o Kubernetes [não vem com um sistema de redes](https://kubernetes.io/docs/setup/production-environment/tools/kubeadm/create-cluster-kubeadm/#pod-network) embutido em sua instalação para comunicação entre os nós, por causa disso temos que instalar algum dos plugins disponíveis. Neste caso instalaremos o plugin mais popular e estável até o momento, o [Calico](https://kubernetes.io/docs/concepts/cluster-administration/networking/#calico), lembre-se de ajustar o `192.168.0.0/24` caso seu *host* esteja em outra faixa de endereçamento, para isto execute:

``` bash
curl -o ~/calico.yaml https://docs.projectcalico.org/manifests/calico.yaml

# Ajuste o `192.168.0.0./24` caso seu cluster esteja rodando em outra faixa de endereçamento.
sed -i "s@# Auto-detect the BGP IP address.@#Auto-detect method for IP address.\n            - name: IP_AUTODETECTION_METHOD\n              value: "cidr=192.168.0.0/24"\n            # Auto-detect the BGP IP address.@g" ~/calico.yaml

sed -i "s@# - name: CALICO_IPV4POOL_CIDR@- name: CALICO_IPV4POOL_CIDR@g" ~/calico.yaml
sed -i "s@#   value: \"192.168.0.0/16\"@  value: \"10.198.0.0/16\"@g" ~/calico.yaml

kubectl apply -f ~/calico.yaml && rm -rfv ~/calico.yaml

curl -o /usr/bin/kubectl-calico -L  https://github.com/projectcalico/calicoctl/releases/download/v3.17.3/calicoctl && chmod +x /usr/bin/kubectl-calico
```

> A versão 1.17 da documentação do Kubernetes trás informações importantes que a versão atual não contempla, você pode acessá-las [aqui](https://v1-17.docs.kubernetes.io/docs/setup/production-environment/tools/kubeadm/create-cluster-kubeadm/#pod-network).

> By default, Calico uses 192.168.0.0/16 as the Pod network CIDR, though this can be configured in the calico.yaml file. For Calico to work correctly, you need to pass this same CIDR to the kubeadm init command using the --pod-network-cidr=192.168.0.0/16 flag or via kubeadm’s configuration.

> Currently Calico is the only CNI plugin that the kubeadm project performs e2e tests against. If you find an issue related to a CNI plugin you should log a ticket in its respective issue tracker instead of the kubeadm or kubernetes issue trackers.

Depois de poucos minutos, o Calico deve estar rodando perfeitamente, para isto verifique:

``` bash
kubectl get pods -n kube-system | grep calico
```

Você também pode acessar o controlador do Calico através deste comando:

``` bash
kubectl calico -h
```

##### 4.1.7.8. Exportando o Token

Agora iremos gerar o *token* de *join* dos nós do cluster, e exportaremos até suas respectivas máquinas virtuais, para isto execute:

``` bash
kubeadm token create $(kubeadm token generate) --ttl=4h0m0m --print-join-command > ~/k8s-join-worker.sh && cp ~/k8s-join-{worker,master}.sh && sed -i "s@--token@--control-plane --token@g" ~/k8s-join-master.sh
```

Neste caso exportamos dois *tokens*, o primeiro deles é o `k8s-join-worker.sh`, que será responsável por adicionar nós do tipo `worker` ao cluster, e o segundo deles é o `k8s-join-master.sh`, que será responsável por adicionar nós do tipo `master` ao cluster.

Agora temos que copiar os *tokens* para os respectivos servidores e executá-los em menos de 04 (quatro) horas, que é o tempo de vida deles.

Para copiar os *tokens* para nossa arquitetura execute:

``` bash
(CURRENT_USER=$(logname); scp ~/k8s-join-worker.sh $CURRENT_USER@t-k8s-worker-01.al.mt.gov.br:)
(CURRENT_USER=$(logname); scp ~/k8s-join-worker.sh $CURRENT_USER@t-k8s-worker-02.al.mt.gov.br:)
```

Depois de copiado os *tokens* eles devem ser apagados, por segurança, então execute:

``` bash
rm -rfv ~/k8s-join-*
```

### 4.2. `t-k8s-worker-01`

Primeiramente suba seus privilégios para o usuário `root`, para que possamos executar procedimentos de instalação e configuração.

``` bash
su -
```

> Durante a instalação do Sistema Operacional você provavelmente definiu uma senha de acesso para o usuário `root`, por este motivo você não encontrará o comando `sudo`.

#### 4.2.1. Rede

Um dos requisitos é a existência de apenas uma interface de rede em sua máquina virtual, caso contrário você terá que configurar uma série de parâmetros a mais. Para checar execute o comando:

``` bash
ls /sys/class/net | grep -v "lo"
```

O resultado deve retornar apenas uma interface de rede, como por exemplo `enp0s3`.

Caso sua instalação exija duas interfaces de rede fique atento aos seguintes avisos:

- O Kubernetes vai escutar apenas uma interface de rede, então lembra-se de procurar informações relativas a estas configurações.
- A última configuração da diretiva `gateway` no arquivo `/etc/network/interface` será marcada como seu `gateway padrão`, então preencha a diretiva apenas para sua interface com saída para a internet.
- Tome cuidado com as diretivas `auto` e `allow-hotplug` no arquivo `/etc/network/interface`, lembrando que a `auto` apresentará erro em caso de desconexão no seu virtualizador e a `allow-hotplug` só ligará depois de uma entrada bem sucedida.

Você pode obter mais informações em: [Debian network interface setup](https://linuxhint.com/debian_network_interface_setup/), [Configuring static routes in debian or red hat linux systems](https://www.cyberciti.biz/tips/configuring-static-routes-in-debian-or-red-hat-linux-systems.html) e [Two default gateways on one system](https://www.thomas-krenn.com/en/wiki/Two_Default_Gateways_on_One_System).

#### 4.2.2. SSH

Vamos desligar o acesso à `root` via SSH, como medida de segurança, então execute:

``` bash
sed -i "s@#PermitRootLogin prohibit-password@PermitRootLogin no@g" /etc/ssh/sshd_config

systemctl restart sshd
```

#### 4.2.3. Hosts

Se você estiver trabalhando em um `cluster` gerencial e com controle de DNS você pode pular esta etapa, mas no nosso caso preciso informar para o *host* como chegar em seus pares, portanto execute:

``` bash
echo "" >> /etc/hosts
# Descomente a linha abaixo caso seu Sistema Operacional não tenha criado essa entrada durante o processo de instalação. Você pode checar através do comando `ping $(hostname)`.
# echo -e "127.0.0.1\tt-k8s-worker-01\tt-k8s-worker-01.al.mt.gov.br" >> /etc/hosts
echo -e "192.168.0.221\tt-k8s-master-01\tt-k8s-master-01.al.mt.gov.br" >> /etc/hosts
echo -e "192.168.0.223\tt-k8s-worker-02\tt-k8s-worker-02.al.mt.gov.br" >> /etc/hosts
```

#### 4.2.4. Atualização

Neste momento vamos atualizar qualquer pacote que esteja desatualizado.

``` bash
apt update && apt upgrade -y
```

#### 4.2.5. Firewall

Vamos instalar um Firewall para proteger nosso *host*, para o presente caso em tela a subrede `192.168.0.0/24` é considerada como uma rede exclusiva de todo o Cluster, se esta não for sua realidade customize a máscara ou faça a liberação para cada IP diretamente.

``` bash
# O comando para instalar o Firewall
apt install -y ufw

# Vamos aplicar a regra padrão, negar tudo para entrada e liberar tudo para saída.
ufw default deny incoming
ufw default allow outgoing

# Vamos liberar acesso à SSH, para que possamos acessá-lo pelo terminal.
ufw allow ssh

# Vamos liberar acesso aos HTTP e HTTPS, porque rodaremos isto no cluster.
ufw allow http
ufw allow https

# Vamos liberar as portas recomendadas pelo Kubernetes
ufw allow from 192.168.0.0/24 to any port 10250 proto tcp
ufw allow from 192.168.0.0/24 to any port 30000:32767 proto tcp

# Vamos liberar as portas recomendadas pelo Calico
ufw allow from 192.168.0.0/24 to any port 179 proto tcp
ufw allow from 192.168.0.0/24 to any port 443 proto tcp
ufw allow from 192.168.0.0/24 to any port 6443 proto tcp
ufw allow from 192.168.0.0/24 to any port 5473 proto tcp
ufw allow from 192.168.0.0/24 to any port 2379 proto tcp
ufw allow from 192.168.0.0/24 to any port 4789 proto udp

# Vamos habilitar as regras acima
ufw enable
```

> Os requerimentos podem ser verificados [aqui](https://kubernetes.io/docs/setup/production-environment/tools/kubeadm/install-kubeadm/#check-required-ports) para o Kubernetes e [aqui](https://docs.projectcalico.org/getting-started/kubernetes/requirements) para o Calico.

#### 4.2.6. Docker

Agora vamos instalar o `container runtime` para o [Kubernetes](https://kubernetes.io/docs/setup/production-environment/container-runtimes/), neste caso instalaremos o [Docker](https://docs.docker.com/engine/install/debian/#install-using-the-repository), para isto execute:

``` bash
mkdir -p /etc/docker /etc/systemd/system/docker.service.d

cat <<EOF | tee /etc/docker/daemon.json
{
  "exec-opts": ["native.cgroupdriver=systemd"],
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "100m"
  },
  "storage-driver": "overlay2",
  "bip": "10.199.0.1/16"
}
EOF
```

Vamos instalar as dependências e o próprio `Docker`:

``` bash
apt install -y apt-transport-https ca-certificates curl gnupg-agent software-properties-common

curl -fsSL https://download.docker.com/linux/debian/gpg | apt-key add -
add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/debian $(lsb_release -cs) stable"

apt update && apt install -y docker-ce docker-ce-cli containerd.io --allow-unauthenticated

systemctl enable docker
```

Caso você queira que seu usuário possa controlar contêineres, execute:

``` bash
usermod -aG docker $(logname)
```

#### 4.2.7. Kubernetes

Nós instalaremos uma instância denominada `bare metal` do Kubernetes, e usaremos a ferramenta `kubeadm` para executar esta atividade.

##### 4.2.7.1. Preparação

A [documentação oficial](https://kubernetes.io/docs/setup/production-environment/tools/kubeadm/install-kubeadm/) do `kubeadm` trás uma série de passos prévios antes de instalar o Kubernetes, então execute:

``` bash
cat <<EOF | tee /etc/modules-load.d/k8s.conf
br_netfilter
EOF

cat <<EOF | tee /etc/sysctl.d/k8s.conf
net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1
EOF

sysctl --system
```

> Os filtros acima permitiram que o `iptables` veja o tráfico em modo `bridge`, conforme descrito [aqui](https://kubernetes.io/docs/setup/production-environment/tools/kubeadm/install-kubeadm/#letting-iptables-see-bridged-traffic).

Agora nós precisamos desligar a memória `swap`, para isto execute:

``` bash
sed -i '/ swap / s/^\(.*\)$/#\1/g' /etc/fstab

swapoff -a
```

> Você pode acompanhar este requisito em [You MUST disable swap in order for the kubelet to work properly](https://kubernetes.io/docs/setup/production-environment/tools/kubeadm/install-kubeadm/#before-you-begin).

##### 4.2.7.2. Instalação

Agora nós iremos instalar as dependências e o próprio Kubernetes, que é o conjunto de `kubectl`, `kubeadm` e `kubelet`, além de algumas imagens, para isto siga as instruções:

``` bash
apt install -y apt-transport-https curl

curl -s https://packages.cloud.google.com/apt/doc/apt-key.gpg | apt-key add -

cat <<EOF | tee /etc/apt/sources.list.d/kubernetes.list
deb https://apt.kubernetes.io/ kubernetes-xenial main
EOF

apt update && apt install -y kubelet kubeadm kubectl

apt-mark hold kubelet kubeadm kubectl

kubeadm config images pull --v 5

systemctl enable kubelet
```

##### 4.2.7.3. Rede

Caso você tenha mais de uma interface de rede você terá que informar o `kubelet` qual ele deve escutar, para isto troque o `enp0s8` pela interface de comunicação com os outros nós do cluster, **caso você tenha só uma interface pule este tópico**, caso contrário execute:

``` bash
(PRIVATE_IP=$(ip -f inet addr show enp0s8 | sed -En -e 's/.*inet ([0-9.]+).*/\1/p'); echo "KUBELET_EXTRA_ARGS=--node-ip=$PRIVATE_IP" >> /etc/default/kubelet)

systemctl daemon-reload

systemctl restart kubelet
```

##### 4.2.7.4. Participando do Cluster

Agora precisamos apenas executar o *script* de *join* que foi exportado da máquina *master*, para isto execute:

``` bash
# Prepare non-root user's variables.
export CURRENT_USER=$(logname)
export CURRENT_HOME=$(getent passwd $CURRENT_USER | cut -d: -f6)

# Join worker on cluster.
sh $CURRENT_HOME/k8s-join-worker.sh && rm -rfv $CURRENT_HOME/k8s-join-*

# Dispose non-root user's information
unset CURRENT_USER CURRENT_HOME
```

##### 4.2.7.6. Checando a Saúde

Você pode executar o(s) comando(s) abaixo para buscar as informações do seu cluster, se algo deu errado algum dos comandos demonstrará:

``` bash
systemctl status kubelet
```

> Caso algo não esteja funcionando adequadamente você pode consultar a [documentação oficial](https://kubernetes.io/docs/tasks/debug-application-cluster/debug-cluster/) de como debuggar o cluster.

### 4.3. `t-k8s-worker-02`

Primeiramente suba seus privilégios para o usuário `root`, para que possamos executar procedimentos de instalação e configuração.

``` bash
su -
```

> Durante a instalação do Sistema Operacional você provavelmente definiu uma senha de acesso para o usuário `root`, por este motivo você não encontrará o comando `sudo`.

#### 4.3.1. Rede

Um dos requisitos é a existência de apenas uma interface de rede em sua máquina virtual, caso contrário você terá que configurar uma série de parâmetros a mais. Para checar execute o comando:

``` bash
ls /sys/class/net | grep -v "lo"
```

O resultado deve retornar apenas uma interface de rede, como por exemplo `enp0s3`.

Caso sua instalação exija duas interfaces de rede fique atento aos seguintes avisos:

- O Kubernetes vai escutar apenas uma interface de rede, então lembra-se de procurar informações relativas a estas configurações.
- A última configuração da diretiva `gateway` no arquivo `/etc/network/interface` será marcada como seu `gateway padrão`, então preencha a diretiva apenas para sua interface com saída para a internet.
- Tome cuidado com as diretivas `auto` e `allow-hotplug` no arquivo `/etc/network/interface`, lembrando que a `auto` apresentará erro em caso de desconexão no seu virtualizador e a `allow-hotplug` só ligará depois de uma entrada bem sucedida.

Você pode obter mais informações em: [Debian network interface setup](https://linuxhint.com/debian_network_interface_setup/), [Configuring static routes in debian or red hat linux systems](https://www.cyberciti.biz/tips/configuring-static-routes-in-debian-or-red-hat-linux-systems.html) e [Two default gateways on one system](https://www.thomas-krenn.com/en/wiki/Two_Default_Gateways_on_One_System).

#### 4.3.2. SSH

Vamos desligar o acesso à `root` via SSH, como medida de segurança, então execute:

``` bash
sed -i "s@#PermitRootLogin prohibit-password@PermitRootLogin no@g" /etc/ssh/sshd_config

systemctl restart sshd
```

#### 4.3.3. Hosts

Se você estiver trabalhando em um `cluster` gerencial e com controle de DNS você pode pular esta etapa, mas no nosso caso preciso informar para o *host* como chegar em seus pares, portanto execute:

``` bash
echo "" >> /etc/hosts
# Descomente a linha abaixo caso seu Sistema Operacional não tenha criado essa entrada durante o processo de instalação. Você pode checar através do comando `ping $(hostname)`.
# echo -e "127.0.0.1\tt-k8s-worker-02\tt-k8s-worker-02.al.mt.gov.br" >> /etc/hosts
echo -e "192.168.0.221\tt-k8s-master-01\tt-k8s-master-01.al.mt.gov.br" >> /etc/hosts
echo -e "192.168.0.222\tt-k8s-worker-01\tt-k8s-worker-01.al.mt.gov.br" >> /etc/hosts
```

#### 4.3.4. Atualização

Neste momento vamos atualizar qualquer pacote que esteja desatualizado.

``` bash
apt update && apt upgrade -y
```

#### 4.3.5. Firewall

Vamos instalar um Firewall para proteger nosso *host*, para o presente caso em tela a subrede `192.168.0.0/24` é considerada como uma rede exclusiva de todo o Cluster, se esta não for sua realidade customize a máscara ou faça a liberação para cada IP diretamente.

``` bash
# O comando para instalar o Firewall
apt install -y ufw

# Vamos aplicar a regra padrão, negar tudo para entrada e liberar tudo para saída.
ufw default deny incoming
ufw default allow outgoing

# Vamos liberar acesso à SSH, para que possamos acessá-lo pelo terminal.
ufw allow ssh

# Vamos liberar acesso aos HTTP e HTTPS, porque rodaremos isto no cluster.
ufw allow http
ufw allow https

# Vamos liberar as portas recomendadas pelo Kubernetes
ufw allow from 192.168.0.0/24 to any port 10250 proto tcp
ufw allow from 192.168.0.0/24 to any port 30000:32767 proto tcp

# Vamos liberar as portas recomendadas pelo Calico
ufw allow from 192.168.0.0/24 to any port 179 proto tcp
ufw allow from 192.168.0.0/24 to any port 443 proto tcp
ufw allow from 192.168.0.0/24 to any port 6443 proto tcp
ufw allow from 192.168.0.0/24 to any port 5473 proto tcp
ufw allow from 192.168.0.0/24 to any port 2379 proto tcp
ufw allow from 192.168.0.0/24 to any port 4789 proto udp

# Vamos habilitar as regras acima
ufw enable
```

> Os requerimentos podem ser verificados [aqui](https://kubernetes.io/docs/setup/production-environment/tools/kubeadm/install-kubeadm/#check-required-ports) para o Kubernetes e [aqui](https://docs.projectcalico.org/getting-started/kubernetes/requirements) para o Calico.

#### 4.3.6. Docker

Agora vamos instalar o `container runtime` para o [Kubernetes](https://kubernetes.io/docs/setup/production-environment/container-runtimes/), neste caso instalaremos o [Docker](https://docs.docker.com/engine/install/debian/#install-using-the-repository), para isto execute:

``` bash
mkdir -p /etc/docker /etc/systemd/system/docker.service.d

cat <<EOF | tee /etc/docker/daemon.json
{
  "exec-opts": ["native.cgroupdriver=systemd"],
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "100m"
  },
  "storage-driver": "overlay2",
  "bip": "10.199.0.1/16"
}
EOF
```

Vamos instalar as dependências e o próprio `Docker`:

``` bash
apt install -y apt-transport-https ca-certificates curl gnupg-agent software-properties-common

curl -fsSL https://download.docker.com/linux/debian/gpg | apt-key add -
add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/debian $(lsb_release -cs) stable"

apt update && apt install -y docker-ce docker-ce-cli containerd.io --allow-unauthenticated

systemctl enable docker
```

Caso você queira que seu usuário possa controlar contêineres, execute:

``` bash
usermod -aG docker $(logname)
```

#### 4.3.7. Kubernetes

Nós instalaremos uma instância denominada `bare metal` do Kubernetes, e usaremos a ferramenta `kubeadm` para executar esta atividade.

##### 4.3.7.1. Preparação

A [documentação oficial](https://kubernetes.io/docs/setup/production-environment/tools/kubeadm/install-kubeadm/) do `kubeadm` trás uma série de passos prévios antes de instalar o Kubernetes, então execute:

``` bash
cat <<EOF | tee /etc/modules-load.d/k8s.conf
br_netfilter
EOF

cat <<EOF | tee /etc/sysctl.d/k8s.conf
net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1
EOF

sysctl --system
```

> Os filtros acima permitiram que o `iptables` veja o tráfico em modo `bridge`, conforme descrito [aqui](https://kubernetes.io/docs/setup/production-environment/tools/kubeadm/install-kubeadm/#letting-iptables-see-bridged-traffic).

Agora nós precisamos desligar a memória `swap`, para isto execute:

``` bash
sed -i '/ swap / s/^\(.*\)$/#\1/g' /etc/fstab

swapoff -a
```

> Você pode acompanhar este requisito em [You MUST disable swap in order for the kubelet to work properly](https://kubernetes.io/docs/setup/production-environment/tools/kubeadm/install-kubeadm/#before-you-begin).

##### 4.3.7.2. Instalação

Agora nós iremos instalar as dependências e o próprio Kubernetes, que é o conjunto de `kubectl`, `kubeadm` e `kubelet`, além de algumas imagens, para isto siga as instruções:

``` bash
apt install -y apt-transport-https curl

curl -s https://packages.cloud.google.com/apt/doc/apt-key.gpg | apt-key add -

cat <<EOF | tee /etc/apt/sources.list.d/kubernetes.list
deb https://apt.kubernetes.io/ kubernetes-xenial main
EOF

apt update && apt install -y kubelet kubeadm kubectl

apt-mark hold kubelet kubeadm kubectl

kubeadm config images pull --v 5

systemctl enable kubelet
```

##### 4.3.7.3. Rede

Caso você tenha mais de uma interface de rede você terá que informar o `kubelet` qual ele deve escutar, para isto troque o `enp0s8` pela interface de comunicação com os outros nós do cluster, **caso você tenha só uma interface pule este tópico**, caso contrário execute:

``` bash
(PRIVATE_IP=$(ip -f inet addr show enp0s8 | sed -En -e 's/.*inet ([0-9.]+).*/\1/p'); echo "KUBELET_EXTRA_ARGS=--node-ip=$PRIVATE_IP" >> /etc/default/kubelet)

systemctl daemon-reload

systemctl restart kubelet
```

##### 4.3.7.4. Participando do Cluster

Agora precisamos apenas executar o *script* de *join* que foi exportado da máquina *master*, para isto execute:

``` bash
# Prepare non-root user's variables.
export CURRENT_USER=$(logname)
export CURRENT_HOME=$(getent passwd $CURRENT_USER | cut -d: -f6)

# Join worker on cluster.
sh $CURRENT_HOME/k8s-join-worker.sh && rm -rfv $CURRENT_HOME/k8s-join-*

# Dispose non-root user's information
unset CURRENT_USER CURRENT_HOME
```

##### 4.3.7.6. Checando a Saúde

Você pode executar o(s) comando(s) abaixo para buscar as informações do seu cluster, se algo deu errado algum dos comandos demonstrará:

``` bash
systemctl status kubelet
```

> Caso algo não esteja funcionando adequadamente você pode consultar a [documentação oficial](https://kubernetes.io/docs/tasks/debug-application-cluster/debug-cluster/) de como debuggar o cluster.

### 5. Administração

Você deve se conectar a uma máquina que tenha poder de administração do cluster, neste tutorial a máquina é a `t-k8s-master-01`.

Nesta máquina execute os comandos abaixo para verificar se toda a instalação aconteceu conforme esperado:

``` bash
kubectl get nodes -o wide

kubectl get pods -n kube-system
```

<!-- ## 6. GlusterFS

O exemplo https://github.com/kubernetes/examples/tree/master/volumes/glusterfs funciona no Cluster; falta agora configurar ele como um PV e PVC.

O exemplo https://docs.okd.io/1.3/install_config/storage_examples/gluster_example.html funciona para a configuração de um PV e PVC.

## 7. MetalLB

https://metallb.universe.tf/installation/

https://metallb.universe.tf/configuration/#layer-2-configuration -->

### 99. Debuggando o Cluster

``` bash
kubectl get nodes -o wide
kubectl get pods --all-namespaces
kubectl describe pods
kubectl -n kube-system describe pods <system-pod-name>
```

Calido está dando problema, o mais provável parece ser por causa das múltiplas interfaces de rede, https://docs.projectcalico.org/reference/node/configuration#ip-autodetection-methods

https://docs.projectcalico.org/networking/ip-autodetection#change-the-autodetection-method

https://stackoverflow.com/questions/48930555/kubernetes-calico-node-crashloopbackoff/55609630 usando interface NAT

https://kubernetes.io/docs/setup/production-environment/tools/kubeadm/troubleshooting-kubeadm/#pods-in-runcontainererror-crashloopbackoff-or-error-state

https://github.com/projectcalico/calico/issues/2720

https://medium.com/@kanrangsan/how-to-specify-internal-ip-for-kubernetes-worker-node-24790b2884fd
