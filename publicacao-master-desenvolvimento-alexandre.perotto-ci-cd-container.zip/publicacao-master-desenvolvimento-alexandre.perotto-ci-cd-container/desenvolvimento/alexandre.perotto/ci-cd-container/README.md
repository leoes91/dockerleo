# Documento de Configuração do Ambiente para CI/CD.

### Pessoas envolvidas e atividades realizadas

> **Alexandre Bossa Perotto** @41028
>
> Responsável por: *Preparação das Máquinas Virtuais*.
> Responsável por: *Instalação do Docker*.
> Responsável por: *Instalação do Swarm*.
> Responsável por: *Instalação e Configuração do Traefik*.
> Responsável por: *Instalação e Configuração do Portainer*.
> Responsável por: *Instalação e Configuração do GitLab*.
> Responsável por: *Instalação e Configuração do Registry*.

### Roteiro de Publicação

#### Avisos Gerais

  - CUSTOMIZE os comandos para sua realidade, lembre que muitas informações são personalizadas para você e para este ambiente em exclusivo, portanto verifique se os endereços de IP's continuam o mesmo.
  - Os servidores não possuem DNS portanto estamos utilizando o ajuste no "hosts", o ideal é que a infraestrutura nos forneça os nomes todos prontos para utilizarmos a saída no gateway para que o DNS padrão nos responda, atualmente eles encontram dificuldades em gerar um DNS para o cluster apesar do tutorial no YouTube usando o AD https://www.youtube.com/watch?v=azBIXmDP9jg mostrar exatamente o contrário.
  - Criamos um novo servidor de SCM, ou seja, um novo GitLab, em uma implantação final em produção isto deve ser modificado e customizado para a realidade da época.
  - O tutorial parte de uma máquina "limpa" quanto aos elementos de rede e anfitrião, se você já usa os recursos de SSH, DNS e afins em sua máquina PENSE antes de executar os comandos, porque poderemos apagar algumas de suas coisas pessoais.

#### 127.0.0.1 | Máquina Local

  - Executar o comando `sudo su -`.
  - Executar o comando `yum install nano -y` para instalar o nano, que é o editor usado neste tutorial.
  - Executar o comando `export EMAIL=seu.email@al.mt.gov.br`.
  - Executar o comando `export USERNAME=sua.matricula.ou.seu.cpf`.
  - Executar o comando `rm -rf ~/.ssh/rd_rsa* && ssh-keygen -t rsa -C "$EMAIL"` para refazer sua chave SSH sem senha.
  - Executar os comandos para adicionar os servidores do cluster como confiáveis:

  ``` bash
  ssh-keyscan -t rsa,dsa 10.1.1.222 >> ~/.ssh/known_hosts
  ssh-keyscan -t rsa,dsa 10.1.1.223 >> ~/.ssh/known_hosts
  ssh-keyscan -t rsa,dsa 10.1.1.224 >> ~/.ssh/known_hosts
  ssh-keyscan -t rsa,dsa 10.1.1.225 >> ~/.ssh/known_hosts
  ssh-keyscan -t rsa,dsa 10.1.1.227 >> ~/.ssh/known_hosts

  ssh-copy-id "$USERNAME"@10.1.1.222
  ssh-copy-id "$USERNAME"@10.1.1.223
  ssh-copy-id "$USERNAME"@10.1.1.224
  ssh-copy-id "$USERNAME"@10.1.1.225
  ssh-copy-id "$USERNAME"@10.1.1.227
  ```

  - Executar o comando `nano -ET4 ~/.ssh/config` com o conteúdo:

  ```txt
  Host docker-manager-01
    HostName 10.1.1.222
    User $USERNAME

  Host docker-manager-02
    HostName 10.1.1.223
    User $USERNAME

  Host docker-manager-03
    HostName 10.1.1.224
    User $USERNAME

  Host docker-manager-04
    HostName 10.1.1.227
    User $USERNAME

  Host scm
    HostName 10.1.1.225
    User $USERNAME

  Host registry
    HostName 10.1.1.225
    User $USERNAME
  ```

  - Executar o comando `sed -i "s/\$USERNAME/$USERNAME/g" ~/.ssh/config` para substituir a palavra reservada pelo conteúdo do seu nome de usuário.

  - Executar o comando `echo "10.1.1.222 portainer.al.mt.gov.br traefik.al.mt.gov.br sonarqube.al.mt.gov.br nexus.al.mt.gov.br pgadmin4.al.mt.gov.br mattermost.al.mt.gov.br" >> /etc/hosts`.
  - Executar o comando `echo "10.1.1.225 git.al.mt.gov.br registry.al.mt.gov.br" >> /etc/hosts`.

  - Acessar esta pasta via terminal, geralmente o comando é `cd ~/publication/desenvolvimento/alexandre.perotto/ci-cd-container` ou similar caso você possua instalação não padrão ou tenha movido o conteúdo para outro diretório.
  - Executar o comando `scp -r portainer/ docker-manager-01: && scp -r traefik/ docker-manager-01: && scp -r gitlab-runner/ docker-manager-01: && scp -r sonarqube/ docker-manager-01: && scp -r nexus/ docker-manager-01: && scp -r pgadmin4/ docker-manager-01: && scp -r mattermost/ docker-manager-01:``.

#### 10.1.1.222 | Docker Manager 01

  - Executar o comando `sudo yum install nano -y` para instalar o nano, que é o editor usado neste tutorial.
  - Executar o comando `sudo yum install -y nfs-utils`.
  - Executar os comandos para criar a estrutura e o serviço de NFS:

  ```bash
  sudo mkdir /media/nfs
  sudo chmod -R 755 /media/nfs
  sudo chown nfsnobody:nfsnobody /media/nfs

  sudo systemctl enable rpcbind
  sudo systemctl enable nfs-server
  sudo systemctl enable nfs-lock
  sudo systemctl enable nfs-idmap
  sudo systemctl start rpcbind
  sudo systemctl start nfs-server
  sudo systemctl start nfs-lock
  sudo systemctl start nfs-idmap
  ```

  - Executar o comando `sudo nano -ET4 /etc/exports` com o conteúdo:

  ```txt
  /media/nfs 10.1.1.222(rw,sync,no_root_squash,no_all_squash)
  /media/nfs 10.1.1.223(rw,sync,no_root_squash,no_all_squash)
  /media/nfs 10.1.1.224(rw,sync,no_root_squash,no_all_squash)
  /media/nfs 10.1.1.227(rw,sync,no_root_squash,no_all_squash)
  ```

  - Executar os comandos para reiniciar o NFS e liberá-lo no firewall da máquina.

  ```bash
  sudo systemctl restart nfs-server

  sudo firewall-cmd --permanent --zone=public --add-service=nfs
  sudo firewall-cmd --permanent --zone=public --add-service=mountd
  sudo firewall-cmd --permanent --zone=public --add-service=rpc-bind
  sudo firewall-cmd --reload
  ```

#### 10.1.1.223 | Docker Manager 02

  - Executar o comando `sudo yum install nano -y` para instalar o nano, que é o editor usado neste tutorial.
  - Executar o comando `sudo yum install -y nfs-utils`.
  - Executar os comandos para criar a estrutura e o serviço de NFS:

  ```bash
  sudo mkdir /media/nfs
  sudo chmod -R 755 /media/nfs
  sudo chown nfsnobody:nfsnobody /media/nfs

  sudo systemctl enable rpcbind
  sudo systemctl enable nfs-server
  sudo systemctl enable nfs-lock
  sudo systemctl enable nfs-idmap
  sudo systemctl start rpcbind
  sudo systemctl start nfs-server
  sudo systemctl start nfs-lock
  sudo systemctl start nfs-idmap
  ```

  - Executar o comando `sudo nano -ET4 /etc/exports` com o conteúdo:

  ```txt
  /media/nfs 10.1.1.222(rw,sync,no_root_squash,no_all_squash)
  /media/nfs 10.1.1.223(rw,sync,no_root_squash,no_all_squash)
  /media/nfs 10.1.1.224(rw,sync,no_root_squash,no_all_squash)
  /media/nfs 10.1.1.227(rw,sync,no_root_squash,no_all_squash)
  ```

  - Executar os comandos para reiniciar o NFS e liberá-lo no firewall da máquina.

  ```bash
  sudo systemctl restart nfs-server

  sudo firewall-cmd --permanent --zone=public --add-service=nfs
  sudo firewall-cmd --permanent --zone=public --add-service=mountd
  sudo firewall-cmd --permanent --zone=public --add-service=rpc-bind
  sudo firewall-cmd --reload
  ```

#### 10.1.1.224 | Docker Manager 03

  - Executar o comando `sudo yum install nano -y` para instalar o nano, que é o editor usado neste tutorial.
  - Executar o comando `sudo yum install -y nfs-utils`.
  - Executar os comandos para criar a estrutura e o serviço de NFS:

  ```bash
  sudo mkdir /media/nfs
  sudo chmod -R 755 /media/nfs
  sudo chown nfsnobody:nfsnobody /media/nfs

  sudo systemctl enable rpcbind
  sudo systemctl enable nfs-server
  sudo systemctl enable nfs-lock
  sudo systemctl enable nfs-idmap
  sudo systemctl start rpcbind
  sudo systemctl start nfs-server
  sudo systemctl start nfs-lock
  sudo systemctl start nfs-idmap
  ```

  - Executar o comando `sudo nano -ET4 /etc/exports` com o conteúdo:

  ```txt
  /media/nfs 10.1.1.222(rw,sync,no_root_squash,no_all_squash)
  /media/nfs 10.1.1.223(rw,sync,no_root_squash,no_all_squash)
  /media/nfs 10.1.1.224(rw,sync,no_root_squash,no_all_squash)
  /media/nfs 10.1.1.227(rw,sync,no_root_squash,no_all_squash)
  ```

  - Executar os comandos para reiniciar o NFS e liberá-lo no firewall da máquina.

  ```bash
  sudo systemctl restart nfs-server

  sudo firewall-cmd --permanent --zone=public --add-service=nfs
  sudo firewall-cmd --permanent --zone=public --add-service=mountd
  sudo firewall-cmd --permanent --zone=public --add-service=rpc-bind
  sudo firewall-cmd --reload
  ```

#### 10.1.1.227 | Docker Manager 04

  - Executar o comando `sudo yum install nano -y` para instalar o nano, que é o editor usado neste tutorial.
  - Executar o comando `sudo yum install -y nfs-utils`.
  - Executar os comandos para criar a estrutura e o serviço de NFS:

  ```bash
  sudo mkdir /media/nfs
  sudo chmod -R 755 /media/nfs
  sudo chown nfsnobody:nfsnobody /media/nfs

  sudo systemctl enable rpcbind
  sudo systemctl enable nfs-server
  sudo systemctl enable nfs-lock
  sudo systemctl enable nfs-idmap
  sudo systemctl start rpcbind
  sudo systemctl start nfs-server
  sudo systemctl start nfs-lock
  sudo systemctl start nfs-idmap
  ```

  - Executar o comando `sudo nano -ET4 /etc/exports` com o conteúdo:

  ```txt
  /media/nfs 10.1.1.222(rw,sync,no_root_squash,no_all_squash)
  /media/nfs 10.1.1.223(rw,sync,no_root_squash,no_all_squash)
  /media/nfs 10.1.1.224(rw,sync,no_root_squash,no_all_squash)
  /media/nfs 10.1.1.227(rw,sync,no_root_squash,no_all_squash)
  ```

  - Executar os comandos para reiniciar o NFS e liberá-lo no firewall da máquina.

  ```bash
  sudo systemctl restart nfs-server

  sudo firewall-cmd --permanent --zone=public --add-service=nfs
  sudo firewall-cmd --permanent --zone=public --add-service=mountd
  sudo firewall-cmd --permanent --zone=public --add-service=rpc-bind
  sudo firewall-cmd --reload
  ```

#### 10.1.1.222 | Docker Manager 01

  - Executar o comando `sudo mkdir -p /mnt/manager-01 /mnt/manager-02 /mnt/manager-03 /mnt/manager-04`.
  - Executar o comando `echo "10.1.1.222:/media/nfs /mnt/manager-01 nfs defaults 0 0" | sudo tee --append /etc/fstab`.
  - Executar o comando `echo "10.1.1.223:/media/nfs /mnt/manager-02 nfs defaults 0 0" | sudo tee --append /etc/fstab`.
  - Executar o comando `echo "10.1.1.224:/media/nfs /mnt/manager-03 nfs defaults 0 0" | sudo tee --append /etc/fstab`.
  - Executar o comando `echo "10.1.1.227:/media/nfs /mnt/manager-04 nfs defaults 0 0" | sudo tee --append /etc/fstab`.
  - Executar o comando `sudo mount -a`.

#### 10.1.1.223 | Docker Manager 02

  - Executar o comando `sudo mkdir -p /mnt/manager-01 /mnt/manager-02 /mnt/manager-03 /mnt/manager-04`.
  - Executar o comando `echo "10.1.1.222:/media/nfs /mnt/manager-01 nfs defaults 0 0" | sudo tee --append /etc/fstab`.
  - Executar o comando `echo "10.1.1.223:/media/nfs /mnt/manager-02 nfs defaults 0 0" | sudo tee --append /etc/fstab`.
  - Executar o comando `echo "10.1.1.224:/media/nfs /mnt/manager-03 nfs defaults 0 0" | sudo tee --append /etc/fstab`.
  - Executar o comando `echo "10.1.1.227:/media/nfs /mnt/manager-04 nfs defaults 0 0" | sudo tee --append /etc/fstab`.
  - Executar o comando `sudo mount -a`.

#### 10.1.1.224 | Docker Manager 03

  - Executar o comando `sudo mkdir -p /mnt/manager-01 /mnt/manager-02 /mnt/manager-03 /mnt/manager-04`.
  - Executar o comando `echo "10.1.1.222:/media/nfs /mnt/manager-01 nfs defaults 0 0" | sudo tee --append /etc/fstab`.
  - Executar o comando `echo "10.1.1.223:/media/nfs /mnt/manager-02 nfs defaults 0 0" | sudo tee --append /etc/fstab`.
  - Executar o comando `echo "10.1.1.224:/media/nfs /mnt/manager-03 nfs defaults 0 0" | sudo tee --append /etc/fstab`.
  - Executar o comando `echo "10.1.1.227:/media/nfs /mnt/manager-04 nfs defaults 0 0" | sudo tee --append /etc/fstab`.
  - Executar o comando `sudo mount -a`.

#### 10.1.1.227 | Docker Manager 04

  - Executar o comando `sudo mkdir -p /mnt/manager-01 /mnt/manager-02 /mnt/manager-03 /mnt/manager-04`.
  - Executar o comando `echo "10.1.1.222:/media/nfs /mnt/manager-01 nfs defaults 0 0" | sudo tee --append /etc/fstab`.
  - Executar o comando `echo "10.1.1.223:/media/nfs /mnt/manager-02 nfs defaults 0 0" | sudo tee --append /etc/fstab`.
  - Executar o comando `echo "10.1.1.224:/media/nfs /mnt/manager-03 nfs defaults 0 0" | sudo tee --append /etc/fstab`.
  - Executar o comando `echo "10.1.1.227:/media/nfs /mnt/manager-04 nfs defaults 0 0" | sudo tee --append /etc/fstab`.
  - Executar o comando `sudo mount -a`.

#### 10.1.1.222 | Docker Manager 01

  - Executar o comando `sudo yum remove -y docker docker-client docker-client-latest docker-common docker-latest docker-latest-logrotate docker-logrotate docker-engine`.
  - Executar o comando `sudo yum install -y yum-utils device-mapper-persistent-data lvm2`.
  - Executar o comando `sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo`.
  - Executar o comando `sudo yum install -y docker-ce docker-ce-cli containerd.io`.
  - Executar o comando `sudo usermod -aG docker $(whoami)`.
  - Executar o comando `sudo mkdir -p /etc/docker`.
  - Executar o comando `sudo systemctl enable docker`.
  - Executar o comando `sudo nano -ET4 /etc/docker/daemon.json` com o conteúdo:

  ```json
  {
    "bip": "192.168.1.1/24"
  }
  ```

  - Executar o comando `sudo systemctl daemon-reload && sudo systemctl restart docker`.
  - Executar o comando `docker network create --subnet 192.168.2.1/24 --gateway 192.168.2.1 -o com.docker.network.bridge.enable_icc=false -o com.docker.network.bridge.name=docker_gwbridge docker_gwbridge`.

  - Executar os comandos liberar as portas de rede para o cluster Swarm:

  ```bash
  sudo firewall-cmd --add-port=2377/tcp --permanent
  sudo firewall-cmd --add-port=7946/tcp --permanent  
  sudo firewall-cmd --add-port=7946/udp --permanent  
  sudo firewall-cmd --add-port=4789/udp --permanent
  sudo systemctl restart firewalld
  ```

  - Executar o comando `docker swarm init --advertise-addr $(ip route get 1 | awk '{print $NF;exit}')`.
  - Executar o comando `echo "docker swarm join --token $(docker swarm join-token --quiet manager) $(ip route get 1 | awk '{print $NF;exit}'):2377" | ssh -o "StrictHostKeyChecking=no" $(whoami)@10.1.1.223 -T "cat > join-token.sh"`.
  - Executar o comando `echo "docker swarm join --token $(docker swarm join-token --quiet manager) $(ip route get 1 | awk '{print $NF;exit}'):2377" | ssh -o "StrictHostKeyChecking=no" $(whoami)@10.1.1.224 -T "cat > join-token.sh"`.
  - Executar o comando `echo "docker swarm join --token $(docker swarm join-token --quiet manager) $(ip route get 1 | awk '{print $NF;exit}'):2377" | ssh -o "StrictHostKeyChecking=no" $(whoami)@10.1.1.227 -T "cat > join-token.sh"`.

  - Executar o comando `docker network rm ingress`.
  - Executar o comando `docker network create --driver overlay --ingress --subnet=192.168.3.1/24 --gateway=192.168.3.1 --opt com.docker.network.driver.mtu=1200 ingress`.

  - Executar o comando `(TOKEN=crDzQ3_Su_YNgZuDqSSv; for FILE in "ca-chain-commercial.crt" "ca-chain.crt" "ca.crt" "chain.crt" "commercial.crt" "private.key" "private.rsa.key"; do curl --insecure --request GET "https://git.al.mt.gov.br/api/v4/projects/8/repository/files/cookbook%2Fdevelopment%2Fcomponents%2Fcerts%2Fal.mt.gov.br%2F2020%2F$FILE/raw?ref=master&private_token=$TOKEN" > $FILE; done;)`.
  - Executar o comando `for file in *.key; do docker secret create "2019-$file" $file; done;`.
  - Executar o comando `for file in *.crt; do docker secret create "2019-$file" $file; done;`.
  - Executar o comando `rm -rf *.crt *.key`.

  - Executar o comando `docker network create --driver=overlay --subnet 192.168.4.1/24 --gateway 192.168.4.1 traefik`. A opção `--opt encryppted` foi removida, porque ela usa tunel de IPSec para trafegar a comunicação entre os nós, acontece que há um problema aberto no fabricante [apontando problemas no kernel linux](https://github.com/moby/moby/issues/33133#issuecomment-351665652).

  - Executar o comando `docker stack deploy -c ~/traefik/docker-stack.yml reverse_proxy && rm -rf ~/traefik`.

  - Executar o comando `sudo mkdir -p /mnt/manager-04/portainer`.
  - Executar o comando `docker stack deploy -c ~/portainer/docker-stack.yml manager && rm -rf ~/portainer`.

  - Executar o comando `sudo mkdir -p /mnt/manager-04/nexus`.

  - Executar o comando `sudo mkdir -p /mnt/manager-04/sonarqube`.
  - Executar o comando `sudo mkdir -p /mnt/manager-04/sonarqube/data`.
  - Executar o comando `sudo mkdir -p /mnt/manager-04/sonarqube/conf`.
  - Executar o comando `sudo mkdir -p /mnt/manager-04/sonarqube/extensions`.
  - Executar o comando `sudo mkdir -p /mnt/manager-04/sonarqube/logs`.
  - Executar o comando `sudo chown polkitd:input -R /mnt/manager-04/sonarqube/`.

  - Executar o comando `sudo mkdir -p /mnt/manager-04/postgresql`.

  - Executar o comando `sudo mkdir -p /mnt/manager-04/mattermost/postgresql`.
  - Executar o comando `sudo mkdir -p /mnt/manager-04/mattermost/{config,data,logs,plugins,client-plugins}`.
  - Executar o comando `sudo chown 2000:2000 /mnt/manager-04/mattermost/{config,data,logs,plugins,client-plugins}`.

#### 10.1.1.223 | Docker Manager 02

  - Executar o comando `sudo yum remove -y docker docker-client docker-client-latest docker-common docker-latest docker-latest-logrotate docker-logrotate docker-engine`.
  - Executar o comando `sudo yum install -y yum-utils device-mapper-persistent-data lvm2`.
  - Executar o comando `sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo`.
  - Executar o comando `sudo yum install -y docker-ce docker-ce-cli containerd.io`.
  - Executar o comando `sudo usermod -aG docker $(whoami)`.
  - Executar o comando `sudo mkdir -p /etc/docker`.
  - Executar o comando `sudo systemctl enable docker`.
  - Executar o comando `sudo nano -ET4 /etc/docker/daemon.json` com o conteúdo:

  ```json
  {
    "bip": "192.168.1.1/24"
  }
  ```

  - Executar o comando `sudo systemctl daemon-reload && sudo systemctl restart docker`.
  - Executar o comando `docker network create --subnet 192.168.2.1/24 --gateway 192.168.2.1 -o com.docker.network.bridge.enable_icc=false -o com.docker.network.bridge.name=docker_gwbridge docker_gwbridge`.

  - Executar os comandos liberar as portas de rede para o cluster Swarm:

  ```bash
  sudo firewall-cmd --add-port=2377/tcp --permanent
  sudo firewall-cmd --add-port=7946/tcp --permanent  
  sudo firewall-cmd --add-port=7946/udp --permanent  
  sudo firewall-cmd --add-port=4789/udp --permanent
  sudo systemctl restart firewalld
  ```

  - Executar o comando `chmod +x ~/join-token.sh && ~/join-token.sh && rm -rf ~/join-token.sh`.

#### 10.1.1.224 | Docker Manager 03

  - Executar o comando `sudo yum remove -y docker docker-client docker-client-latest docker-common docker-latest docker-latest-logrotate docker-logrotate docker-engine`.
  - Executar o comando `sudo yum install -y yum-utils device-mapper-persistent-data lvm2`.
  - Executar o comando `sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo`.
  - Executar o comando `sudo yum install -y docker-ce docker-ce-cli containerd.io`.
  - Executar o comando `sudo usermod -aG docker $(whoami)`.
  - Executar o comando `sudo mkdir -p /etc/docker`.
  - Executar o comando `sudo systemctl enable docker`.
  - Executar o comando `sudo nano -ET4 /etc/docker/daemon.json` com o conteúdo:

  ```json
  {
    "bip": "192.168.1.1/24"
  }
  ```

  - Executar o comando `sudo systemctl daemon-reload && sudo systemctl restart docker`.
  - Executar o comando `docker network create --subnet 192.168.2.1/24 --gateway 192.168.2.1 -o com.docker.network.bridge.enable_icc=false -o com.docker.network.bridge.name=docker_gwbridge docker_gwbridge`.

  - Executar os comandos liberar as portas de rede para o cluster Swarm:

  ```bash
  sudo firewall-cmd --add-port=2377/tcp --permanent
  sudo firewall-cmd --add-port=7946/tcp --permanent  
  sudo firewall-cmd --add-port=7946/udp --permanent  
  sudo firewall-cmd --add-port=4789/udp --permanent
  sudo systemctl restart firewalld
  ```

  - Executar o comando `chmod +x ~/join-token.sh && ~/join-token.sh && rm -rf ~/join-token.sh`.

#### 10.1.1.227 | Docker Manager 04

  - Executar o comando `sudo yum remove -y docker docker-client docker-client-latest docker-common docker-latest docker-latest-logrotate docker-logrotate docker-engine`.
  - Executar o comando `sudo yum install -y yum-utils device-mapper-persistent-data lvm2`.
  - Executar o comando `sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo`.
  - Executar o comando `sudo yum install -y docker-ce docker-ce-cli containerd.io`.
  - Executar o comando `sudo usermod -aG docker $(whoami)`.
  - Executar o comando `sudo mkdir -p /etc/docker`.
  - Executar o comando `sudo systemctl enable docker`.
  - Executar o comando `sudo nano -ET4 /etc/docker/daemon.json` com o conteúdo:

  ```json
  {
    "bip": "192.168.1.1/24"
  }
  ```

  - Executar o comando `sudo systemctl daemon-reload && sudo systemctl restart docker`.
  - Executar o comando `docker network create --subnet 192.168.2.1/24 --gateway 192.168.2.1 -o com.docker.network.bridge.enable_icc=false -o com.docker.network.bridge.name=docker_gwbridge docker_gwbridge`.

  - Executar os comandos liberar as portas de rede para o cluster Swarm:

  ```bash
  sudo firewall-cmd --add-port=2377/tcp --permanent
  sudo firewall-cmd --add-port=7946/tcp --permanent  
  sudo firewall-cmd --add-port=7946/udp --permanent  
  sudo firewall-cmd --add-port=4789/udp --permanent
  sudo systemctl restart firewalld
  ```

  - Executar o comando `chmod +x ~/join-token.sh && ~/join-token.sh && rm -rf ~/join-token.sh`.

#### 10.1.1.225 | SCM | GitLab | Registry

  - Executar o comando `sudo yum install nano -y` para instalar o nano, que é o editor usado neste tutorial.

  - Executar os comandos para liberar as portas no firewall:

  ```bash
  sudo firewall-cmd --permanent --add-service=http
  sudo firewall-cmd --permanent --add-service=https
  sudo systemctl reload firewalld
  ```

  - Executar os comandos para instalar as dependências:

  ```bash
  sudo yum install -y curl policycoreutils-python openssh-server openssh-clients
  sudo systemctl enable sshd
  sudo systemctl start sshd
  sudo firewall-cmd --permanent --add-service=http
  sudo systemctl reload firewalld
  ```

  - Executar os comandos para instalar o notificador de eventos via e-mail:

  ```bash
  sudo yum install postfix
  sudo systemctl enable postfix
  sudo systemctl start postfix
  ```

  - Executar o comando `curl -sS https://packages.gitlab.com/install/repositories/gitlab/gitlab-ce/script.rpm.sh | sudo bash`.
  - Executar o comando `sudo EXTERNAL_URL="https://git.al.mt.gov.br" yum install -y gitlab-ce`.

  - Executar o comando `sudo mkdir -p /etc/gitlab/ssl`.
  - Executar o comando `sudo chmod 700 /etc/gitlab/ssl`.

  - Executar o comando `(TOKEN=crDzQ3_Su_YNgZuDqSSv; for FILE in "ca-chain-commercial.crt" "ca-chain.crt" "ca.crt" "chain.crt" "commercial.crt" "private.key" "private.rsa.key"; do curl --insecure --request GET "https://git.al.mt.gov.br/api/v4/projects/8/repository/files/cookbook%2Fdevelopment%2Fcomponents%2Fcerts%2Fal.mt.gov.br%2F2019%2F$FILE/raw?ref=master&private_token=$TOKEN" > $FILE; done;)`.
  - Executar o comando `sudo mv ca-chain-commercial.crt /etc/gitlab/ssl/al.mt.gov.br.crt`.
  - Executar o comando `sudo mv private.key /etc/gitlab/ssl/al.mt.gov.br.key`.
  - Executar o comando `sudo chmod 600 /etc/gitlab/ssl/al.mt.gov.br.crt /etc/gitlab/ssl/al.mt.gov.br.key`.
  - Executar o comando `rm -rf *.crt *.key`.

  - Executar o comando `sudo nano -ET4 /etc/gitlab/gitlab.rb` e ajuste o seguinte conteúdo:

  ```rb
  external_url 'https://git.al.mt.gov.br'
  registry_external_url 'https://registry.al.mt.gov.br'
  nginx['redirect_http_to_https'] = true
  nginx['ssl_certificate'] = "/etc/gitlab/ssl/al.mt.gov.br.crt"
  nginx['ssl_certificate_key'] = "/etc/gitlab/ssl/al.mt.gov.br.key"
  registry_nginx['ssl_certificate'] = "/etc/gitlab/ssl/al.mt.gov.br.crt"
  registry_nginx['ssl_certificate_key'] = "/etc/gitlab/ssl/al.mt.gov.br.key"
  letsencrypt['enable'] = false
  ```

  - Executar o comando `sudo gitlab-ctl reconfigure`.
  - Executar o comando `sudo gitlab-ctl hup nginx`.

#### 10.1.1.222 | Docker Manager 01

  - Executar o comando `sudo mkdir -p /mnt/gitlab-runner`.

  - Acessar o endereço `https://git.al.mt.gov.br/admin/runners` como administrador de sistema para descobrir o token.

  - Executar o comando `(GITLAB_URL="https://git.al.mt.gov.br/"; GITLAB_TOKEN="Zv6ayyV4inxHNqWvzKVd"; docker run --rm -t -i -v /mnt/gitlab-runner:/etc/gitlab-runner gitlab/gitlab-runner:v13.4.0 register --non-interactive --url "$GITLAB_URL" --registration-token "$GITLAB_TOKEN" --executor "docker" --docker-image alpine:latest --run-untagged="true" --locked="false" --access-level="not_protected" --docker-network-mode bridge --docker-volumes "/var/run/docker.sock:/var/run/docker.sock")` e registrá-lo como executor `docker`.

  <!-- https://docs.gitlab.com/ee/ci/docker/using_docker_build.html#use-docker-in-docker-workflow-with-docker-executor -->

#### 10.1.1.223 | Docker Manager 02

  - Executar o comando `sudo mkdir -p /mnt/gitlab-runner`.

  - Acessar o endereço `https://git.al.mt.gov.br/admin/runners` como administrador de sistema para descobrir o token.

  - Executar o comando `(GITLAB_URL="https://git.al.mt.gov.br/"; GITLAB_TOKEN="Zv6ayyV4inxHNqWvzKVd"; docker run --rm -t -i -v /mnt/gitlab-runner:/etc/gitlab-runner gitlab/gitlab-runner:v13.4.0 register --non-interactive --url "$GITLAB_URL" --registration-token "$GITLAB_TOKEN" --executor "docker" --docker-image alpine:latest --run-untagged="true" --locked="false" --access-level="not_protected" --docker-network-mode bridge --docker-volumes "/var/run/docker.sock:/var/run/docker.sock")` e registrá-lo como executor `docker`.


#### 10.1.1.224 | Docker Manager 03

  - Executar o comando `sudo mkdir -p /mnt/gitlab-runner`.

  - Acessar o endereço `https://git.al.mt.gov.br/admin/runners` como administrador de sistema para descobrir o token.

  - Executar o comando `(GITLAB_URL="https://git.al.mt.gov.br/"; GITLAB_TOKEN="Zv6ayyV4inxHNqWvzKVd"; docker run --rm -t -i -v /mnt/gitlab-runner:/etc/gitlab-runner gitlab/gitlab-runner:v13.4.0 register --non-interactive --url "$GITLAB_URL" --registration-token "$GITLAB_TOKEN" --executor "docker" --docker-image alpine:latest --run-untagged="true" --locked="false" --access-level="not_protected" --docker-network-mode bridge --docker-volumes "/var/run/docker.sock:/var/run/docker.sock")` e registrá-lo como executor `docker`.

#### 10.1.1.227 | Docker Manager 04

  - Executar o comando `sudo mkdir -p /mnt/gitlab-runner`.

  - Acessar o endereço `https://git.al.mt.gov.br/admin/runners` como administrador de sistema para descobrir o token.

  - Executar o comando `(GITLAB_URL="https://git.al.mt.gov.br/"; GITLAB_TOKEN="Zv6ayyV4inxHNqWvzKVd"; docker run --rm -t -i -v /mnt/gitlab-runner:/etc/gitlab-runner gitlab/gitlab-runner:v13.4.0 register --non-interactive --url "$GITLAB_URL" --registration-token "$GITLAB_TOKEN" --executor "docker" --docker-image alpine:latest --run-untagged="true" --locked="false" --access-level="not_protected" --docker-network-mode bridge --docker-volumes "/var/run/docker.sock:/var/run/docker.sock")` e registrá-lo como executor `docker`.

#### 10.1.1.227 | Docker Manager 04

  - Executar o comando `docker node update --label-add sonarqube=true $(docker node ls -f name=$(hostname) -q)`.

  - Executar o comando `sudo su`.
  - Executar os comandos para customizar os limites do sistema, uma vez que este é um dos pré-requisitos do [sonarqube](https://docs.sonarqube.org/latest/requirements/requirements/):

  ```bash
  sysctl -w vm.max_map_count=262144
  sysctl -w fs.file-max=65536
  ulimit -n 65536
  ulimit -u 4096
  ```

  - Executar os comandos para tornar persistente os limites do sistema:

  ```bash
  echo "vm.max_map_count=262144" >> /etc/sysctl.d/99-sonarqube.conf
  echo "fs.file-max=65536" >> /etc/sysctl.d/99-sonarqube.conf
  echo "docker - nofile 65536" >> /etc/security/limits.d/99-sonarqube.conf
  echo "docker - nproc 4096" >> /etc/security/limits.d/99-sonarqube.conf
  ```

  - Executar o comando `exit`.
  - Executar o comando `sudo sysctl -p`.

#### 10.1.1.222 | Docker Manager 01

  - Executar o comando `cd ~ && docker stack deploy -c gitlab-runner/docker-stack.yml ci_cd_agent && rm -rf gitlab-runner`.
  - Executar o comando `cd ~ && docker stack deploy -c sonarqube/docker-stack.yml quality_gate && rm -rf sonarqube`.
  - Executar o comando `cd ~ && docker stack deploy -c nexus/docker-stack.yml artifact_repository && rm -rf nexus`.
  - Executar o comando `cd ~ && docker stack deploy -c pgadmin4/docker-stack.yml database_client && rm -rf pgadmin4`.
  - Executar o comando `cd ~ && docker stack deploy -c mattermost/docker-stack.yml mattermost && rm -rf mattermost`.
  
  - Acompanhe através do `portainer` a criação do `mattermost` e edite o arquivo `/mnt/manager-04/mattermost/config/config.json` e ajuste a chave `DataSource` para as especificadas dentro do arquivo de configuração do `docker-stack.yml` correspondente, uma vez que estas configurações somente poderão ser realizadas através da edição deste arquivo, conforme [documentação oficial](https://docs.mattermost.com/administration/config-settings.html?highlight=postgres#data-source).

### Observações
